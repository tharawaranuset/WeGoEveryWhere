const login = () => {
  return (
    <>
      <div style={{ justifyContent: "center", display: "flex" }}>
        Login Page
      </div>
    </>
  );
};
export default login;
