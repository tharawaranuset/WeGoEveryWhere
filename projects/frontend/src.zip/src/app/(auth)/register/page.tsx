const register = () => {
  return (
    <>
      <div style={{ justifyContent: "center", display: "flex" }}>
        Register Page
      </div>
    </>
  );
};
export default register;
