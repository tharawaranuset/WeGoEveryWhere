const Chatpage = () => {
  return <div className="flex justify-center">Chatpage</div>;
};
export default Chatpage;
