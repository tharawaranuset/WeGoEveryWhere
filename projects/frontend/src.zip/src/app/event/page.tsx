const EventPage = () => {
  return (
    <>
      <div style={{ justifyContent: "center", display: "flex" }}>
        Event Page
      </div>
    </>
  );
};
export default EventPage;
