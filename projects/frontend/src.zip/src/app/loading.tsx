const loading = () => {
  return (
    <div style={{ justifyContent: "center", display: "flex", fontSize: "xl" }}>
      Loading...
    </div>
  );
};
export default loading;
