export default function Home() {
  return (
    <>
      <h1 className="flex justify-center">Home Page</h1>
      <p className="font-sans font-black">นี่คือ Karla (ฟอนต์หลัก)</p>
      <p className="font-alt font-thin">นี่คือ Urbanist (ฟอนต์รอง)</p>
    </>
  );
}
